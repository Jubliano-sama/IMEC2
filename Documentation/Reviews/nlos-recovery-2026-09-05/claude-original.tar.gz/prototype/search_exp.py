import csv, json, math, random, sys, itertools, time
sys.argv = ["x"]
import probe
import numpy as np
from multiprocessing import Pool
from dataclasses import replace

OBJ = probe.OBJECTIVES["p_af_c16_d1"]

def l2_seed_positions(scene, dist_power=0.0, kind="l2", pairs=None):
    sc = scene if pairs is None else replace(scene, pairs=pairs)
    o = probe.Objective(kind, dist_power=dist_power, robust_scale_m=0.2)
    pos, _v, _m, _p = probe.probe_solve(sc, o, flip=False)
    return pos

def short_edge_pairs(scene, k=3):
    by = {}
    for p in scene.pairs:
        by.setdefault(p.anchor_a_id, []).append(p); by.setdefault(p.anchor_b_id, []).append(p)
    keep = set()
    for a, ps in by.items():
        for p in sorted(ps, key=lambda p: p.distance_m)[:k]:
            keep.add(probe.key(p.anchor_a_id, p.anchor_b_id))
    return [p for p in scene.pairs if probe.key(p.anchor_a_id, p.anchor_b_id) in keep]

def finish(prob, x, v):
    return prob.flip_search(x, v)[:2]

def strat_l2(scene, prob):
    x0 = prob.params_from_positions(probe.solve_anchor_layout(scene.pairs, seed_count=8, basin_hops=3).positions_m)
    x, v = prob.local(x0); return finish(prob, x, v)

def strat_d2(scene, prob):
    x0 = prob.params_from_positions(l2_seed_positions(scene, dist_power=2.0))
    x, v = prob.local(x0); return finish(prob, x, v)

def strat_cauchy(scene, prob):
    x0 = prob.params_from_positions(l2_seed_positions(scene, kind="cauchy"))
    x, v = prob.local(x0); return finish(prob, x, v)

def strat_short(scene, prob):
    sub = short_edge_pairs(scene, 3)
    try:
        x0 = prob.params_from_positions(l2_seed_positions(scene, pairs=sub))
    except Exception:
        return strat_l2(scene, prob)
    x, v = prob.local(x0); return finish(prob, x, v)

def strat_gnc(scene, prob):
    x = prob.params_from_positions(probe.solve_anchor_layout(scene.pairs, seed_count=8, basin_hops=3).positions_m)
    for ns in (1.0, 0.5, 0.25, 0.1, 0.05):
        p2 = probe.ProbeProblem(scene, replace(OBJ, neg_sigma_m=ns))
        x, v = p2.local(x)
        x, v, _ = p2.flip_search(x, v, max_sweeps=2)
    return prob.local(x)

def strat_hop(scene, prob, hops=40, seed=3):
    rng = random.Random(seed)
    x0 = prob.params_from_positions(probe.solve_anchor_layout(scene.pairs, seed_count=8, basin_hops=3).positions_m)
    x, v = prob.local(x0)
    x, v, _ = prob.flip_search(x, v)
    best_x, best_v = x, v
    cur_x, cur_v = x, v
    for h in range(hops):
        P = probe.params_to_xy(cur_x, prob.n)
        if rng.random() < 0.5:
            a = rng.randrange(prob.n)
            nn = prob.nbrs[a][:4]
            if len(nn) < 2: continue
            b, c = rng.sample(nn, 2)
            u = P[c] - P[b]; L = np.linalg.norm(u)
            if L < 0.1: continue
            u = u / L; w = P[a] - P[b]
            Q = P.copy(); Q[a] = P[b] + 2.0 * np.dot(w, u) * u - w
        else:
            Q = P + np.array([[rng.gauss(0, 0.6), rng.gauss(0, 0.6)] for _ in range(prob.n)])
        xa, va = prob.local(probe.xy_to_params(probe.level(Q)))
        if va < cur_v or rng.random() < math.exp(-(va - cur_v) / 5.0):
            cur_x, cur_v = xa, va
            if va < best_v:
                best_x, best_v = xa, va
    best_x, best_v, _ = prob.flip_search(best_x, best_v)
    return best_x, best_v

STRATS = {"l2": strat_l2, "d2seed": strat_d2, "cauchyseed": strat_cauchy, "shortseed": strat_short, "gnc": strat_gnc, "hop": strat_hop}

def run(job):
    rep, gap, lo, hi, name = job
    rng = random.Random(1000 + rep)
    scene = probe.build_scene("x", probe.drawing_truth(), probe.drawing_walls(gap), rng, los_radius=12.0, nlos_radius=12.0,
                              sigma=0.03, bias_lo=lo, bias_hi=hi, shadow=probe.drawing_shadow("hetero"))
    prob = probe.ProbeProblem(scene, OBJ)
    x_or, v_or = prob.local(prob.params_from_positions(scene.truth))
    t0 = time.perf_counter()
    x, v = STRATS[name](scene, prob)
    dt = time.perf_counter() - t0
    pos = prob.positions(x)
    o = probe.drawing_orientation_flip(scene.truth, pos)
    loo = probe.loo_offsets(scene.truth, pos)
    flips = sum(1 for a in scene.los_group if loo[a] > 1.0)
    return dict(rep=rep, gap=gap, lo=lo, strat=name, value=v, oracle=v_or, orient=o, flips=flips, dt=dt)

if __name__ == "__main__":
    jobs = [(rep, gap, lo, hi, name) for name in STRATS for (lo, hi) in ((1.6, 3.0), (3.0, 5.0)) for gap in (0.0, 1.5) for rep in range(10)]
    with Pool(6) as pool:
        rows = pool.map(run, jobs)
    print(f"{'strat':<11} {'bias':>4} {'gap':>4} {'Tflip':>5} {'LOOflip':>7} {'reachOracle':>11} {'mean(v-oracle)':>14} {'medT':>5}")
    for name in STRATS:
        for lo in (1.6, 3.0):
            for gap in (0.0, 1.5):
                rs = [r for r in rows if r["strat"] == name and r["lo"] == lo and r["gap"] == gap]
                print(f"{name:<11} {lo:>4} {gap:>4} {sum(r['orient']==1 for r in rs):>5} {sum(r['flips']>0 for r in rs):>7} "
                      f"{sum(r['value'] <= r['oracle'] + 1e-3 for r in rs):>11} {np.mean([r['value']-r['oracle'] for r in rs]):>14.1f} {np.median([r['dt'] for r in rs]):>5.1f}")
