import csv, json, math, sys, random
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.argv = ["x"]
import probe

SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e6e5e2"
C_T, C_G, C_N = "#eb6834", "#2a78d6", "#1baf7a"   # slots 2, 1, 3 of the reference palette

def load(path, method, scene):
    for r in csv.DictReader(open(path)):
        if r["method"] == method and r["scene"] == scene:
            return {k: tuple(v) for k, v in json.loads(r["positions"]).items()}, {k: tuple(v) for k, v in json.loads(r["truth"]).items()}
    raise KeyError(scene)

scene_name = "drawing_b1.6-3_g0_hetero_cap0_r1"
gui, truth = load("drawing_hetero2.csv", "gui_intervals", scene_name)
new, _ = load("drawing_scan.csv", "p_af_c16_d1", scene_name)
rng = random.Random(1000)
scene = probe.build_scene("x", probe.drawing_truth(), probe.drawing_walls(0.0), rng, los_radius=12.0, nlos_radius=12.0,
                          sigma=0.03, bias_lo=1.6, bias_hi=3.0, shadow=probe.drawing_shadow("hetero"))

def align_to_truth(est, ref_ids):
    ids = sorted(truth)
    T = np.array([truth[i] for i in ids]); S = np.array([est[i] for i in ids])
    fi = [ids.index(i) for i in ref_ids]
    tm, sm = T[fi].mean(0), S[fi].mean(0)
    best = None
    for refl in (1.0, -1.0):
        Sr = (S - sm).copy(); Sr[:, 1] *= refl
        u, _, vt = np.linalg.svd(Sr[fi].T @ (T[fi] - tm))
        d = np.sign(np.linalg.det(u @ vt)); rot = u @ np.diag([1.0, d]) @ vt
        A = Sr @ rot + tm
        err = np.linalg.norm(A[fi] - T[fi], axis=1).mean()
        if best is None or err < best[0]:
            best = (err, A)
    return {i: tuple(best[1][k]) for k, i in enumerate(ids)}

ref = ["N1", "N2", "N3", "N4", "G1", "G2", "G3"]
gui_a = align_to_truth(gui, ref)
new_a = align_to_truth(new, ref)

def color_of(a):
    return C_T if a == "T" else (C_G if a.startswith("G") else C_N)

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.8), facecolor=SURF)
panels = [("Ground truth and measured links", truth, True), ("Current solver (Neighbor intervals)", gui_a, False), ("One-sided loss + distance weight", new_a, False)]
for ax, (title, pos, show_edges) in zip(axes, panels):
    ax.set_facecolor(SURF)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_aspect("equal")
    ax.set_xlim(-0.5, 14.0); ax.set_ylim(-1.5, 11.5)
    ax.set_xticks([0, 5, 10]); ax.set_yticks([0, 5, 10])
    ax.tick_params(colors=INK2, labelsize=9, length=0)
    ax.grid(True, color=GRID, linewidth=1)
    ax.set_title(title, color=INK, fontsize=11, loc="left", pad=8)
    # wall
    for (p, q) in scene.walls:
        ax.plot([p[0], q[0]], [p[1], q[1]], color=INK2, linewidth=5, solid_capstyle="butt", zorder=1)
    ax.text(0.2, 6.35, "wall", color=INK2, fontsize=9)
    if show_edges:
        for p in scene.pairs:
            k = probe.key(p.anchor_a_id, p.anchor_b_id)
            a, b = pos[p.anchor_a_id], pos[p.anchor_b_id]
            if k in scene.nlos_edges:
                if "T" in k:
                    ax.plot([a[0], b[0]], [a[1], b[1]], color=C_T, linewidth=1.2, linestyle=(0, (3, 3)), alpha=0.9, zorder=2)
                else:
                    ax.plot([a[0], b[0]], [a[1], b[1]], color=INK2, linewidth=0.8, linestyle=(0, (2, 3)), alpha=0.45, zorder=2)
            else:
                ax.plot([a[0], b[0]], [a[1], b[1]], color=INK2, linewidth=0.8, alpha=0.35, zorder=2)
    else:
        # faint truth rings underneath, and a displacement line for T
        for a, (x, y) in truth.items():
            ax.scatter([x], [y], s=90, facecolors="none", edgecolors=INK2, linewidths=1.2, alpha=0.5, zorder=3)
        tx, ty = truth["T"]; px, py = pos["T"]
        ax.annotate("", xy=(px, py), xytext=(tx, ty), arrowprops=dict(arrowstyle="->", color=C_T, lw=1.5), zorder=4)
        ax.text(0.5 * (tx + px), min(ty, py) - 0.9, f"T moved {math.dist((tx, ty), (px, py)):.1f} m", color=INK2, fontsize=9, ha="center")
    for a, (x, y) in pos.items():
        ax.scatter([x], [y], s=80, color=color_of(a), edgecolors=SURF, linewidths=2, zorder=5)
        ax.text(x + 0.25, y + 0.25, a, color=INK, fontsize=9, zorder=6)
handles = [
    plt.Line2D([], [], marker="o", color=C_T, linestyle="", markersize=8, label="T: shadowed anchor"),
    plt.Line2D([], [], marker="o", color=C_G, linestyle="", markersize=8, label="G: line-of-sight neighbours"),
    plt.Line2D([], [], marker="o", color=C_N, linestyle="", markersize=8, label="N: anchors behind the wall"),
    plt.Line2D([], [], color=C_T, linestyle=(0, (3, 3)), linewidth=1.2, label="T's NLOS links (biased +1.6 to +3 m)"),
    plt.Line2D([], [], color=INK2, linestyle=(0, (2, 3)), linewidth=0.8, alpha=0.6, label="lightly biased NLOS links"),
    plt.Line2D([], [], color=INK2, linewidth=0.8, alpha=0.5, label="line-of-sight links"),
]
fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False, fontsize=9, labelcolor=INK2, bbox_to_anchor=(0.5, -0.02))
fig.suptitle("Sketch scene: NLOS bias on the shadowed anchor mirrors it across its collinear neighbours", color=INK, fontsize=12, x=0.02, ha="left")
fig.tight_layout(rect=(0, 0.08, 1, 0.95))
fig.savefig("/tmp/nlos_probe/drawing_scene.png", dpi=130, facecolor=SURF)
print("saved", "T offset current:", round(math.dist(truth["T"], gui_a["T"]), 2), "proposed:", round(math.dist(truth["T"], new_a["T"]), 2))
