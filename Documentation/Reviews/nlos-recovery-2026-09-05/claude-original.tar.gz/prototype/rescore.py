"""Offline re-scoring: flips judged within the line-of-sight group only."""
import csv, json, sys, math
import numpy as np
sys.argv = ["x"]
import probe

def los_group(truth):
    # wall at y=6 in every scene
    return sorted(a for a, p in truth.items() if p[1] < 6.0)

def score(row):
    if row["status"] != "ok":
        return None
    truth = {k: tuple(v) for k, v in json.loads(row["truth"]).items()}
    pos = {k: tuple(v) for k, v in json.loads(row["positions"]).items()}
    los = los_group(truth)
    if len(los) < 4:
        return None
    # leave-one-out within LOS group
    loo = {}
    for a in los:
        others = [b for b in los if b != a]
        loo[a] = probe.align_offsets(truth, pos, others)[a]
    aligned = probe.align_offsets(truth, pos, los)
    return {
        "los_loo_flips": sum(1 for a in los if loo[a] > 1.0),
        "los_loo_max": max(loo.values()),
        "los_max": max(aligned[a] for a in los),
        "los_rms": math.sqrt(np.mean([aligned[a] ** 2 for a in los])),
    }

def main(paths):
    rows = []
    for p in paths:
        for r in csv.DictReader(open(p)):
            s = score(r)
            if s is None:
                continue
            r.update(s)
            r["file"] = p
            rows.append(r)
    groups = {}
    for r in rows:
        g = (r["file"], r.get("meta_shadow"), r.get("meta_cap"), r.get("meta_bias_lo"), r.get("meta_gap"), r["method"])
        groups.setdefault(g, []).append(r)
    print(f"{'file':<20} {'shadow':<7} {'cap':>3} {'bias':>4} {'gap':>3} {'method':<22} {'n':>3} {'losLOO>1m%':>10} {'losMax>0.5%':>11} {'medLosMax':>9} {'medLosRMS':>9}")
    for g in sorted(groups, key=lambda k: (k[0], str(k[1]), str(k[2]), float(k[3] or 0), float(k[4] or 0), k[5])):
        rs = groups[g]
        fl = np.array([r["los_loo_flips"] for r in rs])
        mx = np.array([r["los_max"] for r in rs])
        print(f"{g[0][:20]:<20} {str(g[1]):<7} {str(g[2]):>3} {g[3]:>4} {g[4]:>3} {g[5]:<22} {len(rs):>3} {100*np.mean(fl>0):>9.0f}% {100*np.mean(mx>0.5):>10.0f}% {np.median(mx):>9.2f} {np.median([r['los_rms'] for r in rs]):>9.2f}")

if __name__ == "__main__":
    main(sys.argv[1:] if len(sys.argv) > 1 else ["family.csv"])
