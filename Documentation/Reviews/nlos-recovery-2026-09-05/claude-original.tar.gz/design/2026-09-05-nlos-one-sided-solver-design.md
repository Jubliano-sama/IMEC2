# NLOS one-sided intervals solver

Date: 2026-09-05
Status: approved in chat (Tommie, 2026-09-05); implement as a new selectable solver

## Goal

Add a fourth selectable anchor geometry solver to the gateway GUI that does not mirror an anchor across its near-collinear neighbours when most of that anchor's other links are NLOS. The existing solvers stay unchanged and remain selectable; the default solver stays `Neighbor intervals`.

## Why the current solvers flip

All three existing solvers minimise symmetric least squares on every measured range with a fixed 0.05 m sigma. UWB NLOS bias is one-sided: a wall makes a range longer, never shorter. An anchor deep in a wall shadow has links to far anchors that are metres too long, while its near neighbours see those same far anchors with little bias, so the solver cannot absorb the error by moving the far cluster. The cheapest remaining explanation is to move the shadowed anchor away from the cluster, and with near-collinear neighbours the mirrored position costs nothing on the near links. The truth-seeded optimum of the symmetric objective is itself the mirrored layout, so this is an objective defect, not a search defect.

The spike that established this (2026-09-05, throwaway probe in `/tmp/nlos_probe`) reproduced the flip at 80 to 100% on a scene matching Tommie's sketch for 1.6 to 5 m biases, and showed the recipe below brings it to 0% there and to 0% mirrored line-of-sight anchors on 144 random wall layouts, with the line-of-sight group RMS dropping from about 0.23 m to 0.04 m.

## What this is not

- Not a replacement for `Neighbor intervals`, `Visibility branching tuned`, or `Visibility branching neighbor-aware tuned`. They stay as they are.
- Not a new GUI control. Solver parameters are keyword arguments with defaults; the GUI passes only what it passes today (seed, radio interval, current layout).
- Not an NLOS classifier. The solver never decides which link is NLOS from signal level or a map; it only stops trusting a range as a lower bound on the model distance.
- Not a simulator change. Extending `AnchorGeometrySolver` with wall scenes is a separate task.

## Name and location

- Algorithm constant `NLOS_ONE_SIDED_ALGORITHM = "NLOS one-sided intervals"`.
- New module `tools/gateway_gui/anchor_geometry_nlos.py` exporting `solve_nlos_one_sided_layout(...)`.
- Result `algorithm` string: `"NLOS one-sided intervals (7-15 m); seed <seed name>"`, matching the `Neighbor intervals` format so the GUI's status text and tests read the same way.

## Inputs

Same signature family as `solve_connectivity_interval_layout`:

```python
def solve_nlos_one_sided_layout(
    pairs: Iterable[AnchorPairDistance],
    *,
    neighbor_pairs: Iterable[tuple[str, str]],
    nonneighbor_pairs: Iterable[tuple[str, str]],
    seed: str = SEED_AUTO,
    current_positions_m: dict[str, tuple[float, float]] | None = None,
    neighbor_max_m: float = DEFAULT_NEIGHBOR_MAX_M,
    nonneighbor_min_m: float = DEFAULT_NONNEIGHBOR_MIN_M,
    interval_sigma_m: float = 0.75,
    plateau: float = 16.0,
    distance_weight_power: float = 1.0,
    bias_cap_m: float = 8.0,
    max_nfev: int = 600,
) -> AnchorLayoutResult
```

Validation is identical to `Neighbor intervals`: `0 < nonneighbor_min_m <= neighbor_max_m`, positive `interval_sigma_m`, a pair cannot be both neighbour and non-neighbour, a measured pair cannot be a non-neighbour, the measured graph must be connected. New parameters: `plateau > 0`, `distance_weight_power >= 0`, `bias_cap_m > 0`.

## Objective

Preprocess pairs with `_preprocess_pairs(min_sigma_m=0.02, min_distance_m=0.05)` exactly as the other solvers do, so per-pair sigma `s` and the anchor ordering match. Parameterise positions with `_Parameterization` (anchor 0 at the origin, anchor 1 on the positive x axis), which keeps `rotate_layout_to_level` and the GUI frame conventions unchanged.

For each processed pair with measured distance `m`, model distance `d`, residual `r = d - m`, sigma `s`, and weight `w = (d_ref / max(m, 0.3)) ** distance_weight_power` where `d_ref` is the median measured distance:

- `r >= 0` (model longer than measured, physically implausible beyond noise): residual term `sqrt(w) * r / s`.
- `r < 0` (model shorter than measured, consistent with a positive NLOS bias): residual term `-sqrt(w) * sqrt(plateau * (1 - exp(-(r / s) ** 2 / plateau)) + (max(0, -r - bias_cap_m) / s) ** 2)`.

The negative side behaves like the symmetric loss inside about three sigma and saturates at `plateau` sigma-squared units beyond that, so a badly biased link stops pulling. The tolerance on that side is the pair sigma itself; it must not be widened, because a wide negative tolerance makes shrinking every edge cheap and the line-of-sight links lose their grip on the geometry. The cap makes a bias beyond `bias_cap_m` implausible again, which prevents the layout from collapsing when many links are on the plateau.

Interval hinges are the same as `Neighbor intervals` and apply to every neighbour pair, measured or not: neighbour `max(0, d - neighbor_max_m) / interval_sigma_m`, confirmed non-neighbour `max(0, nonneighbor_min_m - d) / interval_sigma_m`.

The objective is the sum of squared residual terms. Residual evaluation is vectorised with numpy over index arrays; the scipy `least_squares` call uses `method="trf"`, `x_scale="jac"`, and `max_nfev`.

## Search

1. Seeds: the same seed families as `Neighbor intervals` (`_seed_families` from `anchor_geometry_connectivity`), so `Auto`, `Current layout`, `Visibility branching`, `Measured-distance spring`, and `Graph MDS` all work. Under `Auto`, each seed also gets two Gaussian perturbations of `0.08 * max measured distance` from a `random.Random(1337)` generator, as `Neighbor intervals` does.
2. Local solve from every start; keep the lowest objective.
3. Reflection search on the best candidate. Anchors are visited in sorted ID order. For each anchor take its four nearest measured neighbours by measured distance. For every pair of them whose separation exceeds 0.1 m, reflect the anchor across the line through that pair, skip the candidate if it moved less than 0.2 m, re-level the layout, run a local solve with `max_nfev=300`, and accept it when the objective improves by more than `1e-6`. Repeat for at most three sweeps and stop after a sweep with no acceptance. Count accepted reflections in `basin_hop_count`.

The reflection search is required because a gradient optimiser cannot move an anchor across the circles of its near neighbours; the symmetric seeds usually start on the mirrored side.

## Output

`AnchorLayoutResult` with:

- `positions_m` levelled with `rotate_layout_to_level` on the first two sorted anchors and cleaned with `_clean_positions`.
- `energy` = final objective, `rmse_m` and `max_residual_m` from `pair_residuals`, `residuals_m`, `processed_pairs`.
- `warnings`: the standard `_layout_warnings`, the two interval-violation warnings in the `Neighbor intervals` wording, and one solver-specific warning listing links whose model distance is shorter than measured by more than three sigma, formatted as `"3 link(s) treated as NLOS: A-B (+1.23 m), ..."` sorted by descending excess. This is the user's visibility into which ranges the solver stopped trusting.
- `seed_count` = number of local-solve starts, `basin_hop_count` = accepted reflections.

## GUI wiring

- `diagnostic_models.solve_geometry` dispatches `NLOS_ONE_SIDED_ALGORITHM` to the new function with the same keyword arguments it passes to `Neighbor intervals`.
- `survey_view.SOLVER_CHOICES` gains the new name after `Neighbor intervals`; `RADIO_INTERVAL_SOLVERS` includes it so the radio min/max spinboxes apply.
- `diagnostics_integration` currently repeats the interval-solver tuple twice by hand. Replace both with `RADIO_INTERVAL_SOLVERS` imported from `survey_view`, which it already imports, so a new interval solver is registered in one place.
- README `Geometry And Mesh Diagnostics` gains one paragraph describing the solver, when to pick it, and the NLOS warning.
- One line in `AGENT_KNOWN_ISSUES.md` recording the flip cause and the fix.

## Tests

New file `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`:

1. Residual shape: a positive residual scales as `r / s`; a negative residual saturates near `sqrt(plateau)`; a negative residual beyond `bias_cap_m` grows again; `distance_weight_power=0` gives unit weights.
2. Sketch regression: a deterministic synthetic scene built in the test (eight anchors at the sketch coordinates, a wall at y = 6, seeded Gaussian noise of 0.03 m, NLOS bias 1.6 to 3.0 m on the shadowed anchor's wall-crossing links and 15% of that on the neighbours' wall-crossing links). Assert that `Neighbor intervals` places the shadowed anchor on the wrong side of the line through its two outer neighbours relative to the far cluster, and the new solver places it on the correct side within 0.3 m after rigid alignment on the other anchors. Use `seed=SEED_SPRING` for the baseline to keep the test fast.
3. Exact geometry: with noise-free distances and no NLOS the new solver reproduces every distance to better than 1e-3 m and emits no NLOS warning.
4. Determinism: two calls with the same inputs return identical positions.
5. Validation errors: overlapping neighbour and non-neighbour sets, a measured non-neighbour pair, a bad interval, a non-positive plateau, and a negative weight power each raise `ValueError`.
6. NLOS warning: the sketch scene's warning names the shadowed anchor's biased links.
7. Dispatch: `solve_geometry(..., solver=NLOS_ONE_SIDED_ALGORITHM)` reaches the new function with the seed, interval, and pair sets, mirroring the existing dispatch tests.
8. Registration: `SOLVER_CHOICES` and `RADIO_INTERVAL_SOLVERS` contain the new name, and `diagnostics_integration` no longer defines its own interval-solver tuple.

Gates: `.venv/bin/python -m unittest discover -s tools/gateway_gui/tests`, `compileall`, and the documented mypy command all pass.

## Known limits (documented in README)

- With every far link NLOS, bias at least the mirror distance, and collinear near neighbours, ranges alone cannot decide the side; one line-of-sight link through a gap resolves it. This solver leaves such an anchor where the search found it, so the manual mirror control still matters.
- The one-sided loss needs redundancy. It is meant for the merged `Survey All Neighbors` dataset; on a single degree-capped pass every solver, including this one, is under-determined.
- Residual failure mode near a wall gap: the solver can warp a few short line-of-sight links to fit some lightly biased long links exactly. Distance weighting suppresses most of it; it is not eliminated.
