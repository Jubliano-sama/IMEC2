# NLOS One-Sided Intervals Solver Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a fourth selectable GUI geometry solver, `NLOS one-sided intervals`, that stops mirroring a shadowed anchor across its near-collinear neighbours by treating a too-long range as plausible NLOS instead of a symmetric error.

**Architecture:** One new module `tools/gateway_gui/anchor_geometry_nlos.py` owns the one-sided residual, a vectorised scipy least-squares problem, and a per-anchor reflection search; it reuses the seed families, pair preprocessing, parameterisation, and result type of the existing solvers. The GUI registers the new name in the existing dispatch, solver choice tuple, and radio-interval set; `diagnostics_integration` stops hand-listing interval solvers.

**Tech Stack:** Python 3.13, numpy, scipy `least_squares`, unittest, mypy.

**Spec:** `docs/superpowers/specs/2026-09-05-nlos-one-sided-solver-design.md`

## Global Constraints

- Run everything from the worktree root `/home/tommie/.t3/worktrees/IMEC2/t3code-14f7b03f`. Do not `cd` into the original checkout.
- The worktree has no `.venv`; use `PY=/home/tommie/Projects/IMEC2/.venv/bin/python` (it has numpy, scipy, mypy). The system `python3` lacks scipy and must not be used.
- Algorithm name constant is exactly `NLOS_ONE_SIDED_ALGORITHM = "NLOS one-sided intervals"`; the result `algorithm` string is `"NLOS one-sided intervals (<min:g>-<max:g> m); seed <seed name>"`.
- Defaults: `plateau=16.0`, `distance_weight_power=1.0`, `bias_cap_m=8.0`, `interval_sigma_m=0.75`, `max_nfev=600`, neighbour radius defaults imported from `anchor_geometry_connectivity`.
- The negative-side tolerance is the per-pair sigma from `_preprocess_pairs`; never introduce a separate wider tolerance.
- The default GUI solver stays `Neighbor intervals`.
- No GUI controls are added.
- Commit each task on the current branch `t3code/fix-nlos-anchor-flips` with a short imperative subject line and a body that ends with `Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>`. Never push, never rebase, never touch the stash.
- Gates before a task is done: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v` (new file), and at the end of the plan the full `$PY -m unittest discover -s tools/gateway_gui/tests`, `$PY -m compileall -q tools/gateway_gui`, and `$PY -m mypy --explicit-package-bases --exclude 'tools/gateway_gui/tests/' tools/gateway_gui`.

---

## File map

- Create `tools/gateway_gui/anchor_geometry_nlos.py`: one-sided residual (`one_sided_residual`), `_OneSidedProblem` (vectorised residuals, local solve, reflection search), `solve_nlos_one_sided_layout`.
- Create `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`: residual shape, exact geometry, determinism, validation, NLOS warning, sketch regression, registration.
- Modify `tools/gateway_gui/diagnostic_models.py`: import and dispatch the new solver in `solve_geometry`.
- Modify `tools/gateway_gui/survey_view.py`: add the name to `SOLVER_CHOICES` and `RADIO_INTERVAL_SOLVERS`.
- Modify `tools/gateway_gui/diagnostics_integration.py`: use `RADIO_INTERVAL_SOLVERS` instead of two hand-written tuples.
- Modify `tools/gateway_gui/tests/test_geometry_diagnostics.py`: dispatch test for the new name.
- Modify `tools/gateway_gui/README.md` and `AGENT_KNOWN_ISSUES.md`: documentation.

---

### Task 1: One-sided residual

**Files:**
- Create: `tools/gateway_gui/anchor_geometry_nlos.py`
- Test: `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`

**Interfaces:**
- Produces: `one_sided_residual(residual_m: np.ndarray, sigma_m: np.ndarray, *, plateau: float, bias_cap_m: float) -> np.ndarray`, constants `NLOS_ONE_SIDED_ALGORITHM`, `DEFAULT_PLATEAU`, `DEFAULT_DISTANCE_WEIGHT_POWER`, `DEFAULT_BIAS_CAP_M`, `NLOS_SUSPECT_SIGMAS`.

- [ ] **Step 1: Write the failing tests**

Create `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`:

```python
import math
import random
import unittest
from unittest.mock import patch

import numpy as np

from tools.gateway_gui.anchor_geometry import AnchorPairDistance
from tools.gateway_gui.anchor_geometry_nlos import (
    DEFAULT_BIAS_CAP_M,
    DEFAULT_PLATEAU,
    NLOS_ONE_SIDED_ALGORITHM,
    one_sided_residual,
)


def pair(a, b, distance, sigma=0.05):
    return AnchorPairDistance(a, b, distance, sigma)


class OneSidedResidualTests(unittest.TestCase):
    def test_positive_residual_keeps_the_symmetric_scale(self):
        terms = one_sided_residual(
            np.array([0.0, 0.10, 1.0]),
            np.array([0.05, 0.05, 0.05]),
            plateau=DEFAULT_PLATEAU,
            bias_cap_m=DEFAULT_BIAS_CAP_M,
        )
        np.testing.assert_allclose(terms, [0.0, 2.0, 20.0])

    def test_negative_residual_matches_symmetric_scale_near_zero(self):
        terms = one_sided_residual(
            np.array([-0.01]),
            np.array([0.05]),
            plateau=DEFAULT_PLATEAU,
            bias_cap_m=DEFAULT_BIAS_CAP_M,
        )
        self.assertAlmostEqual(float(terms[0]), -0.2, places=2)

    def test_negative_residual_saturates_at_the_plateau(self):
        terms = one_sided_residual(
            np.array([-1.0, -2.0, -5.0]),
            np.array([0.05, 0.05, 0.05]),
            plateau=16.0,
            bias_cap_m=DEFAULT_BIAS_CAP_M,
        )
        for term in terms:
            self.assertLess(term, 0.0)
            self.assertAlmostEqual(float(term), -4.0, places=3)

    def test_negative_residual_beyond_the_cap_grows_again(self):
        inside, outside = one_sided_residual(
            np.array([-7.0, -9.0]),
            np.array([0.05, 0.05]),
            plateau=16.0,
            bias_cap_m=8.0,
        )
        self.assertAlmostEqual(float(inside), -4.0, places=3)
        self.assertAlmostEqual(float(outside), -math.sqrt(16.0 + 20.0 ** 2), places=3)

    def test_algorithm_name(self):
        self.assertEqual(NLOS_ONE_SIDED_ALGORITHM, "NLOS one-sided intervals")


if __name__ == "__main__":
    unittest.main()
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: ImportError, `No module named 'tools.gateway_gui.anchor_geometry_nlos'`.

- [ ] **Step 3: Create the module with the residual**

Create `tools/gateway_gui/anchor_geometry_nlos.py`:

```python
"""One-sided NLOS-tolerant anchor solver for survey ranging graphs.

UWB non-line-of-sight bias only ever lengthens a range. The symmetric solvers
treat a too-long range like a too-short one, so an anchor whose far links
cross a wall is pushed away from those anchors until it mirrors across its
near neighbours. This solver keeps the ranging sigma when the model distance
is longer than the measured one and lets the penalty saturate when the model
is shorter, so a biased link stops pulling. An explicit reflection search
visits both mirror hypotheses per anchor because a gradient step cannot cross
the circles of the near neighbours on its own.
"""

from __future__ import annotations

from collections.abc import Iterable
import itertools
import math
import random

import numpy as np

from .anchor_geometry import (
    AnchorLayoutResult,
    AnchorPairDistance,
    ProcessedAnchorPair,
    _Parameterization,
    _anchor_ids,
    _clean_positions,
    _layout_warnings,
    _positions_to_params,
    _preprocess_pairs,
    _rmse,
    _validate_connected,
    pair_residuals,
    rotate_layout_to_level,
)
from .anchor_geometry_connectivity import (
    DEFAULT_NEIGHBOR_MAX_M,
    DEFAULT_NONNEIGHBOR_MIN_M,
    PairKey,
    _normalize_constraints,
    _seed_families,
    pair_key,
)
from .anchor_geometry_seeds import SEED_AUTO


NLOS_ONE_SIDED_ALGORITHM = "NLOS one-sided intervals"
DEFAULT_PLATEAU = 16.0
DEFAULT_DISTANCE_WEIGHT_POWER = 1.0
DEFAULT_BIAS_CAP_M = 8.0
NLOS_SUSPECT_SIGMAS = 3.0


def one_sided_residual(
    residual_m: np.ndarray,
    sigma_m: np.ndarray,
    *,
    plateau: float,
    bias_cap_m: float,
) -> np.ndarray:
    """Return signed residual terms whose squares form the one-sided cost.

    ``residual_m`` is model minus measured distance. A positive residual means
    the model is longer than the range, which NLOS cannot explain, so it keeps
    the symmetric ``residual / sigma`` scale. A negative residual saturates at
    ``plateau`` sigma-squared units so a biased link stops pulling, and grows
    again once the implied bias exceeds ``bias_cap_m``.
    """

    scaled = residual_m / sigma_m
    positive = scaled >= 0.0
    terms = np.empty_like(scaled)
    terms[positive] = scaled[positive]
    negative = scaled[~positive]
    cost = plateau * (1.0 - np.exp(-(negative * negative) / plateau))
    over = np.maximum(0.0, -residual_m[~positive] - bias_cap_m) / sigma_m[~positive]
    terms[~positive] = -np.sqrt(cost + over * over)
    return terms
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: 5 tests, OK.

---

### Task 2: Vectorised problem, local solve, and reflection search

**Files:**
- Modify: `tools/gateway_gui/anchor_geometry_nlos.py` (append below `one_sided_residual`)
- Test: `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`

**Interfaces:**
- Consumes: `one_sided_residual` from Task 1; `_Parameterization`, `_positions_to_params`, `rotate_layout_to_level` from `anchor_geometry`.
- Produces: class `_OneSidedProblem(anchor_ids, processed, neighbors, nonneighbors, *, neighbor_max_m, nonneighbor_min_m, interval_sigma_m, plateau, distance_weight_power, bias_cap_m)` with `parameterization`, `positions_array(params) -> np.ndarray`, `positions(params) -> dict[str, tuple[float, float]]`, `params_from_array(points) -> np.ndarray | None`, `residual_terms(params) -> np.ndarray`, `objective(params) -> float`, `local_solve(params, *, max_nfev) -> tuple[np.ndarray, float]`, `reflection_search(params, objective) -> tuple[np.ndarray, float, int]`, and helper `_reflect_across(point, line_a, line_b) -> np.ndarray`.

- [ ] **Step 1: Write the failing tests**

Append to the test file (add `_OneSidedProblem`, `_reflect_across` to the import from `anchor_geometry_nlos`, and `from tools.gateway_gui.anchor_geometry import _preprocess_pairs, _anchor_ids` at the top):

```python
class OneSidedProblemTests(unittest.TestCase):
    def _problem(self, pairs, **overrides):
        processed = _preprocess_pairs(pairs, min_sigma_m=0.02, min_distance_m=0.05)
        anchor_ids = _anchor_ids(processed)
        settings = dict(
            neighbor_max_m=15.0,
            nonneighbor_min_m=7.0,
            interval_sigma_m=0.75,
            plateau=16.0,
            distance_weight_power=0.0,
            bias_cap_m=8.0,
        )
        settings.update(overrides)
        return _OneSidedProblem(anchor_ids, processed, frozenset(), frozenset(), **settings)

    def test_positions_array_matches_parameterization(self):
        pairs = [pair("A", "B", 3.0), pair("A", "C", 4.0), pair("B", "C", 5.0)]
        problem = self._problem(pairs)
        params = np.array([3.0, 0.0, 4.0])
        expected = problem.parameterization.to_positions(params.tolist())
        points = problem.positions_array(params)
        for row, anchor_id in enumerate(problem.anchor_ids):
            self.assertEqual(tuple(points[row]), expected[anchor_id])

    def test_exact_layout_has_zero_objective(self):
        pairs = [pair("A", "B", 3.0), pair("A", "C", 4.0), pair("B", "C", 5.0)]
        problem = self._problem(pairs)
        self.assertAlmostEqual(problem.objective(np.array([3.0, 0.0, 4.0])), 0.0, places=9)

    def test_distance_weight_power_scales_short_links_up(self):
        pairs = [pair("A", "B", 1.0), pair("A", "C", 4.0), pair("B", "C", 4.0)]
        unweighted = self._problem(pairs, distance_weight_power=0.0)
        weighted = self._problem(pairs, distance_weight_power=1.0)
        np.testing.assert_allclose(unweighted.sqrt_weights, [1.0, 1.0, 1.0])
        self.assertGreater(weighted.sqrt_weights[0], weighted.sqrt_weights[1])
        self.assertAlmostEqual(float(weighted.sqrt_weights[1]), 1.0)

    def test_local_solve_recovers_exact_triangle(self):
        pairs = [pair("A", "B", 3.0), pair("A", "C", 4.0), pair("B", "C", 5.0)]
        problem = self._problem(pairs)
        params, objective = problem.local_solve(np.array([2.5, 0.5, 3.5]), max_nfev=200)
        self.assertLess(objective, 1e-8)
        positions = problem.positions(params)
        self.assertAlmostEqual(math.dist(positions["A"], positions["C"]), 4.0, places=5)

    def test_reflect_across_mirrors_point_over_line(self):
        reflected = _reflect_across(np.array([0.0, 1.0]), np.array([0.0, 0.0]), np.array([1.0, 0.0]))
        np.testing.assert_allclose(reflected, [0.0, -1.0])

    def test_reflection_search_crosses_a_collinear_pair(self):
        # D is held by A and B on the x axis and by one link to C below the
        # axis. Mirrored below the axis, D satisfies A and B exactly and its
        # C link is far too short, which the one-sided loss saturates, so a
        # gradient step has nothing to follow; only a reflection finds the
        # exact layout.
        truth = {"A": (0.0, 0.0), "B": (4.0, 0.0), "C": (2.0, -3.0), "D": (1.0, 2.0)}
        pairs = [
            pair("A", "B", 4.0),
            pair("A", "C", math.sqrt(13.0)),
            pair("B", "C", math.sqrt(13.0)),
            pair("A", "D", math.sqrt(5.0)),
            pair("B", "D", math.sqrt(13.0)),
            pair("C", "D", math.sqrt(26.0)),
        ]
        problem = self._problem(pairs)
        mirrored = dict(truth)
        mirrored["D"] = (1.0, -2.0)
        start = problem.params_from_array(np.array([mirrored[a] for a in problem.anchor_ids]))
        self.assertIsNotNone(start)
        params, objective = problem.local_solve(start, max_nfev=300)
        self.assertGreater(objective, 10.0)
        best, best_objective, accepted = problem.reflection_search(params, objective)
        self.assertLess(best_objective, 1e-6)
        self.assertGreaterEqual(accepted, 1)
        self.assertAlmostEqual(abs(problem.positions(best)["D"][1]), 2.0, places=3)
        self.assertAlmostEqual(math.dist(problem.positions(best)["C"], problem.positions(best)["D"]), math.sqrt(26.0), places=3)

    def test_interval_hinges_add_terms(self):
        # Square A(0,0) B(3,0) C(3,4) D(0,4) with A-D unmeasured.
        pairs = [
            pair("A", "B", 3.0),
            pair("B", "C", 4.0),
            pair("C", "D", 3.0),
            pair("A", "C", 5.0),
            pair("B", "D", 5.0),
        ]
        processed = _preprocess_pairs(pairs, min_sigma_m=0.02, min_distance_m=0.05)
        problem = _OneSidedProblem(
            _anchor_ids(processed),
            processed,
            frozenset({("A", "B")}),
            frozenset({("A", "D")}),
            neighbor_max_m=2.0,
            nonneighbor_min_m=9.0,
            interval_sigma_m=0.75,
            plateau=16.0,
            distance_weight_power=0.0,
            bias_cap_m=8.0,
        )
        exact = problem.params_from_array(np.array([[0.0, 0.0], [3.0, 0.0], [3.0, 4.0], [0.0, 4.0]]))
        np.testing.assert_allclose(
            problem.residual_terms(exact),
            [0.0, 0.0, 0.0, 0.0, 0.0, 1.0 / 0.75, 5.0 / 0.75],
            atol=1e-9,
        )
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: ImportError for `_OneSidedProblem`.

- [ ] **Step 3: Implement the problem class**

Append to `tools/gateway_gui/anchor_geometry_nlos.py`:

```python
def _reflect_across(point: np.ndarray, line_a: np.ndarray, line_b: np.ndarray) -> np.ndarray:
    """Mirror ``point`` across the infinite line through ``line_a`` and ``line_b``."""

    direction = line_b - line_a
    unit = direction / float(np.linalg.norm(direction))
    offset = point - line_a
    return line_a + 2.0 * float(np.dot(offset, unit)) * unit - offset


class _OneSidedProblem:
    """Vectorised one-sided objective over the shared anchor parameterisation."""

    def __init__(
        self,
        anchor_ids: list[str],
        processed: list[ProcessedAnchorPair],
        neighbors: frozenset[PairKey],
        nonneighbors: frozenset[PairKey],
        *,
        neighbor_max_m: float,
        nonneighbor_min_m: float,
        interval_sigma_m: float,
        plateau: float,
        distance_weight_power: float,
        bias_cap_m: float,
    ) -> None:
        self.anchor_ids = list(anchor_ids)
        self.index = {anchor_id: row for row, anchor_id in enumerate(self.anchor_ids)}
        self.count = len(self.anchor_ids)
        self.parameterization = _Parameterization(self.anchor_ids)
        self.neighbor_max_m = neighbor_max_m
        self.nonneighbor_min_m = nonneighbor_min_m
        self.interval_sigma_m = interval_sigma_m
        self.plateau = plateau
        self.bias_cap_m = bias_cap_m
        x_slots = []
        y_slots = []
        for anchor_id in self.anchor_ids:
            x_index = self.parameterization.derivative_index(anchor_id, "x")
            y_index = self.parameterization.derivative_index(anchor_id, "y")
            x_slots.append(-1 if x_index is None else x_index)
            y_slots.append(-1 if y_index is None else y_index)
        self._x_slots = np.asarray(x_slots, dtype=int)
        self._y_slots = np.asarray(y_slots, dtype=int)
        self.pair_a = np.asarray([self.index[item.anchor_a_id] for item in processed], dtype=int)
        self.pair_b = np.asarray([self.index[item.anchor_b_id] for item in processed], dtype=int)
        self.measured = np.asarray([item.distance_m for item in processed], dtype=float)
        self.sigma = np.asarray([item.sigma_m for item in processed], dtype=float)
        reference = float(np.median(self.measured)) if self.measured.size else 1.0
        weights = (reference / np.maximum(self.measured, 0.3)) ** distance_weight_power
        self.sqrt_weights = np.sqrt(weights)
        neighbor_list = sorted(neighbors)
        nonneighbor_list = sorted(nonneighbors)
        self.neighbor_a = np.asarray([self.index[a] for a, _b in neighbor_list], dtype=int)
        self.neighbor_b = np.asarray([self.index[b] for _a, b in neighbor_list], dtype=int)
        self.nonneighbor_a = np.asarray([self.index[a] for a, _b in nonneighbor_list], dtype=int)
        self.nonneighbor_b = np.asarray([self.index[b] for _a, b in nonneighbor_list], dtype=int)
        self.nearest: dict[int, list[int]] = {row: [] for row in range(self.count)}
        for edge in np.argsort(self.measured, kind="stable"):
            first = int(self.pair_a[edge])
            second = int(self.pair_b[edge])
            self.nearest[first].append(second)
            self.nearest[second].append(first)

    def positions_array(self, params: np.ndarray) -> np.ndarray:
        padded = np.concatenate([np.asarray(params, dtype=float), [0.0]])
        xs = padded[np.where(self._x_slots >= 0, self._x_slots, padded.size - 1)]
        ys = padded[np.where(self._y_slots >= 0, self._y_slots, padded.size - 1)]
        return np.column_stack([xs, ys])

    def positions(self, params: np.ndarray) -> dict[str, tuple[float, float]]:
        points = self.positions_array(params)
        return {
            anchor_id: (float(points[row, 0]), float(points[row, 1]))
            for anchor_id, row in self.index.items()
        }

    def params_from_array(self, points: np.ndarray) -> np.ndarray | None:
        positions = {
            anchor_id: (float(points[row, 0]), float(points[row, 1]))
            for anchor_id, row in self.index.items()
        }
        try:
            levelled = rotate_layout_to_level(positions, self.anchor_ids[0], self.anchor_ids[1])
        except ValueError:
            return None
        return np.asarray(_positions_to_params(self.parameterization, levelled), dtype=float)

    def residual_terms(self, params: np.ndarray) -> np.ndarray:
        points = self.positions_array(params)
        model = np.linalg.norm(points[self.pair_a] - points[self.pair_b], axis=1)
        terms = [
            self.sqrt_weights
            * one_sided_residual(
                model - self.measured,
                self.sigma,
                plateau=self.plateau,
                bias_cap_m=self.bias_cap_m,
            )
        ]
        if self.neighbor_a.size:
            neighbor_distance = np.linalg.norm(points[self.neighbor_a] - points[self.neighbor_b], axis=1)
            terms.append(np.maximum(0.0, neighbor_distance - self.neighbor_max_m) / self.interval_sigma_m)
        if self.nonneighbor_a.size:
            nonneighbor_distance = np.linalg.norm(
                points[self.nonneighbor_a] - points[self.nonneighbor_b], axis=1
            )
            terms.append(
                np.maximum(0.0, self.nonneighbor_min_m - nonneighbor_distance) / self.interval_sigma_m
            )
        return np.concatenate(terms)

    def objective(self, params: np.ndarray) -> float:
        terms = self.residual_terms(params)
        return float(np.dot(terms, terms))

    def local_solve(self, params: np.ndarray, *, max_nfev: int) -> tuple[np.ndarray, float]:
        from scipy.optimize import least_squares  # type: ignore[import-untyped]

        start = np.asarray(params, dtype=float)
        if start.size == 0:
            return start, self.objective(start)
        result = least_squares(
            self.residual_terms,
            start,
            method="trf",
            x_scale="jac",
            max_nfev=max(1, max_nfev),
        )
        solved = np.asarray(result.x, dtype=float)
        return solved, self.objective(solved)

    def reflection_search(
        self,
        params: np.ndarray,
        objective: float,
        *,
        max_sweeps: int = 3,
        nearest_count: int = 4,
        max_nfev: int = 300,
    ) -> tuple[np.ndarray, float, int]:
        """Try each anchor's mirror across lines through its nearest neighbours."""

        best_params = np.asarray(params, dtype=float)
        best_objective = objective
        accepted = 0
        for _sweep in range(max_sweeps):
            improved = False
            for anchor in range(self.count):
                candidates = self.nearest[anchor][:nearest_count]
                for first, second in itertools.combinations(candidates, 2):
                    points = self.positions_array(best_params)
                    if float(np.linalg.norm(points[second] - points[first])) <= 0.1:
                        continue
                    reflected = _reflect_across(points[anchor], points[first], points[second])
                    if float(np.linalg.norm(reflected - points[anchor])) < 0.2:
                        continue
                    moved = points.copy()
                    moved[anchor] = reflected
                    start = self.params_from_array(moved)
                    if start is None:
                        continue
                    candidate, value = self.local_solve(start, max_nfev=max_nfev)
                    if value < best_objective - 1e-6:
                        best_params = candidate
                        best_objective = value
                        accepted += 1
                        improved = True
            if not improved:
                break
        return best_params, best_objective, accepted
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: 12 tests, OK. `test_reflection_search_crosses_a_collinear_pair` must not be weakened: at the mirrored start the C-D model distance is 1.41 m against a 5.10 m range, which sits on the plateau with no gradient, so the local solve is expected to stay near objective 16 and only the reflection can reach zero.

---

### Task 3: Public solve function with seeds, warnings, and result

**Files:**
- Modify: `tools/gateway_gui/anchor_geometry_nlos.py` (append)
- Test: `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`

**Interfaces:**
- Consumes: `_OneSidedProblem` from Task 2; `_seed_families`, `_normalize_constraints`, `pair_key` from `anchor_geometry_connectivity`.
- Produces: `solve_nlos_one_sided_layout(pairs, *, neighbor_pairs, nonneighbor_pairs, seed=SEED_AUTO, current_positions_m=None, neighbor_max_m=DEFAULT_NEIGHBOR_MAX_M, nonneighbor_min_m=DEFAULT_NONNEIGHBOR_MIN_M, interval_sigma_m=0.75, plateau=DEFAULT_PLATEAU, distance_weight_power=DEFAULT_DISTANCE_WEIGHT_POWER, bias_cap_m=DEFAULT_BIAS_CAP_M, max_nfev=600) -> AnchorLayoutResult`.

- [ ] **Step 1: Write the failing tests**

Append to the test file (add `solve_nlos_one_sided_layout` to the import and `from tools.gateway_gui.anchor_geometry_seeds import SEED_AUTO, SEED_SPRING`):

```python
class SolveNlosOneSidedTests(unittest.TestCase):
    def _square_pairs(self):
        positions = {"A": (0.0, 0.0), "B": (6.0, 0.0), "C": (6.0, 5.0), "D": (0.0, 5.0), "E": (3.0, 2.0)}
        pairs = [
            pair(first, second, math.dist(positions[first], positions[second]))
            for first, second in (
                ("A", "B"), ("B", "C"), ("C", "D"), ("A", "D"), ("A", "C"),
                ("A", "E"), ("B", "E"), ("C", "E"), ("D", "E"),
            )
        ]
        return positions, pairs

    def test_exact_geometry_is_reproduced_without_nlos_warning(self):
        _positions, pairs = self._square_pairs()
        result = solve_nlos_one_sided_layout(
            pairs, neighbor_pairs=set(), nonneighbor_pairs=set(), seed=SEED_SPRING,
        )
        self.assertLess(result.max_residual_m, 1e-3)
        self.assertTrue(result.algorithm.startswith("NLOS one-sided intervals (7-15 m); seed "))
        self.assertFalse(any("treated as NLOS" in warning for warning in result.warnings))

    def test_determinism(self):
        _positions, pairs = self._square_pairs()
        first = solve_nlos_one_sided_layout(pairs, neighbor_pairs=set(), nonneighbor_pairs=set())
        second = solve_nlos_one_sided_layout(pairs, neighbor_pairs=set(), nonneighbor_pairs=set())
        self.assertEqual(first.positions_m, second.positions_m)

    def test_biased_link_is_reported_and_ignored(self):
        _positions, pairs = self._square_pairs()
        biased = pairs + [pair("B", "D", math.hypot(6.0, 5.0) + 2.0)]
        result = solve_nlos_one_sided_layout(
            biased, neighbor_pairs=set(), nonneighbor_pairs=set(), seed=SEED_SPRING,
        )
        nlos = [warning for warning in result.warnings if "treated as NLOS" in warning]
        self.assertEqual(len(nlos), 1)
        self.assertIn("B-D (+", nlos[0])
        self.assertAlmostEqual(
            math.dist(result.positions_m["A"], result.positions_m["C"]), math.hypot(6.0, 5.0), places=2,
        )

    def test_interval_and_constraint_validation(self):
        _positions, pairs = self._square_pairs()
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(pairs, neighbor_pairs={("A", "B")}, nonneighbor_pairs={("A", "B")})
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(pairs, neighbor_pairs=set(), nonneighbor_pairs={("A", "B")})
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(
                pairs, neighbor_pairs=set(), nonneighbor_pairs=set(), nonneighbor_min_m=20.0, neighbor_max_m=15.0,
            )
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(pairs, neighbor_pairs=set(), nonneighbor_pairs=set(), plateau=0.0)
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(
                pairs, neighbor_pairs=set(), nonneighbor_pairs=set(), distance_weight_power=-1.0,
            )
        with self.assertRaises(ValueError):
            solve_nlos_one_sided_layout(pairs, neighbor_pairs=set(), nonneighbor_pairs=set(), bias_cap_m=0.0)
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: ImportError for `solve_nlos_one_sided_layout`.

- [ ] **Step 3: Implement the solve function**

Append to `tools/gateway_gui/anchor_geometry_nlos.py`:

```python
def solve_nlos_one_sided_layout(
    pairs: Iterable[AnchorPairDistance],
    *,
    neighbor_pairs: Iterable[tuple[str, str]],
    nonneighbor_pairs: Iterable[tuple[str, str]],
    seed: str = SEED_AUTO,
    current_positions_m: dict[str, tuple[float, float]] | None = None,
    neighbor_max_m: float = DEFAULT_NEIGHBOR_MAX_M,
    nonneighbor_min_m: float = DEFAULT_NONNEIGHBOR_MIN_M,
    interval_sigma_m: float = 0.75,
    plateau: float = DEFAULT_PLATEAU,
    distance_weight_power: float = DEFAULT_DISTANCE_WEIGHT_POWER,
    bias_cap_m: float = DEFAULT_BIAS_CAP_M,
    max_nfev: int = 600,
) -> AnchorLayoutResult:
    """Solve measured ranges with a one-sided NLOS-tolerant loss.

    Ranges are lower bounds on nothing and upper bounds on everything: a model
    distance longer than a range is penalised with the ranging sigma, a model
    distance shorter than a range costs at most ``plateau`` sigma-squared
    units. Short links are weighted up by ``(median / distance) **
    distance_weight_power`` because short links are rarely NLOS. Radio
    neighbour intervals apply exactly as in ``Neighbor intervals``.
    """

    if not 0.0 < nonneighbor_min_m <= neighbor_max_m:
        raise ValueError("Radio interval must satisfy 0 < minimum <= maximum.")
    if interval_sigma_m <= 0.0:
        raise ValueError("Radio interval sigma must be positive.")
    if plateau <= 0.0:
        raise ValueError("NLOS plateau must be positive.")
    if distance_weight_power < 0.0:
        raise ValueError("Distance weight power must be zero or greater.")
    if bias_cap_m <= 0.0:
        raise ValueError("NLOS bias cap must be positive.")
    known_pairs = list(pairs)
    processed = _preprocess_pairs(known_pairs, min_sigma_m=0.02, min_distance_m=0.05)
    anchor_ids = _anchor_ids(processed)
    _validate_connected(anchor_ids, processed)
    anchor_set = set(anchor_ids)
    neighbors = _normalize_constraints(neighbor_pairs, anchor_set)
    nonneighbors = _normalize_constraints(nonneighbor_pairs, anchor_set)
    if neighbors & nonneighbors:
        raise ValueError("A pair cannot be both a neighbor and a non-neighbor.")
    measured = {pair_key(item.anchor_a_id, item.anchor_b_id) for item in processed}
    if measured & nonneighbors:
        raise ValueError("A measured pair cannot be constrained as a non-neighbor.")

    problem = _OneSidedProblem(
        anchor_ids,
        processed,
        neighbors,
        nonneighbors,
        neighbor_max_m=neighbor_max_m,
        nonneighbor_min_m=nonneighbor_min_m,
        interval_sigma_m=interval_sigma_m,
        plateau=plateau,
        distance_weight_power=distance_weight_power,
        bias_cap_m=bias_cap_m,
    )
    base_seeds = _seed_families(known_pairs, anchor_ids, nonneighbors, seed, current_positions_m)
    rng = random.Random(1337)
    scale = max((item.distance_m for item in processed), default=1.0)
    candidates: list[tuple[float, str, np.ndarray]] = []
    for seed_name, base_positions in base_seeds:
        oriented = rotate_layout_to_level(base_positions, anchor_ids[0], anchor_ids[1])
        first = np.asarray(_positions_to_params(problem.parameterization, oriented), dtype=float)
        starts = [first]
        if seed == SEED_AUTO:
            for _ in range(2):
                starts.append(first + np.asarray([rng.gauss(0.0, 0.08 * scale) for _ in first]))
        for start in starts:
            params, objective = problem.local_solve(start, max_nfev=max_nfev)
            candidates.append((objective, seed_name, params))
    objective, selected_seed, params = min(candidates, key=lambda item: item[0])
    params, objective, accepted_reflections = problem.reflection_search(params, objective)

    positions = rotate_layout_to_level(problem.positions(params), anchor_ids[0], anchor_ids[1])
    positions = _clean_positions(positions)
    residual_map = pair_residuals(positions, processed)
    rmse = _rmse(residual_map.values())
    max_residual = max((abs(value) for value in residual_map.values()), default=0.0)
    warnings = list(_layout_warnings(anchor_ids, processed, rmse, max_residual))
    neighbor_violations = sum(
        1 for a, b in neighbors if math.dist(positions[a], positions[b]) > neighbor_max_m + 1e-6
    )
    nonneighbor_violations = sum(
        1 for a, b in nonneighbors if math.dist(positions[a], positions[b]) < nonneighbor_min_m - 1e-6
    )
    if neighbor_violations:
        warnings.append(f"{neighbor_violations} neighbor interval(s) exceed {neighbor_max_m:.1f} m")
    if nonneighbor_violations:
        warnings.append(
            f"{nonneighbor_violations} non-neighbor interval(s) are below {nonneighbor_min_m:.1f} m"
        )
    suspects: list[tuple[float, str]] = []
    for item in processed:
        residual = residual_map[f"{item.anchor_a_id}-{item.anchor_b_id}"]
        if residual < -NLOS_SUSPECT_SIGMAS * item.sigma_m:
            suspects.append((-residual, f"{item.anchor_a_id}-{item.anchor_b_id} (+{-residual:.2f} m)"))
    if suspects:
        listed = ", ".join(text for _excess, text in sorted(suspects, reverse=True))
        warnings.append(f"{len(suspects)} link(s) treated as NLOS: {listed}")
    return AnchorLayoutResult(
        algorithm=(
            f"{NLOS_ONE_SIDED_ALGORITHM} ({nonneighbor_min_m:g}-{neighbor_max_m:g} m); "
            f"seed {selected_seed}"
        ),
        energy=objective,
        rmse_m=rmse,
        max_residual_m=max_residual,
        positions_m=positions,
        processed_pairs=tuple(processed),
        residuals_m=residual_map,
        warnings=tuple(warnings),
        seed_count=len(candidates),
        basin_hop_count=accepted_reflections,
    )
```

Note: `pair_residuals` labels use `anchor_a_id-anchor_b_id` from the processed pair, which is already sorted, so the lookup key above matches.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: 16 tests, OK.

- [ ] **Step 5: Run mypy on the new module**

Run: `$PY -m mypy --explicit-package-bases --exclude 'tools/gateway_gui/tests/' tools/gateway_gui`
Expected: `Success: no issues found`. If mypy complains about `np.ndarray | None` returns or `frozenset[PairKey]`, add explicit annotations; do not add `# type: ignore` beyond the scipy import.

---

### Task 4: Sketch regression test

**Files:**
- Test: `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`

**Interfaces:**
- Consumes: `solve_nlos_one_sided_layout` from Task 3; `solve_connectivity_interval_layout` from `anchor_geometry_connectivity`.

- [ ] **Step 1: Write the scene builder and the regression test**

Append to the test file (add `from tools.gateway_gui.anchor_geometry_connectivity import solve_connectivity_interval_layout`):

```python
SKETCH_TRUTH = {
    "N1": (2.7, 8.3), "N2": (4.0, 8.3), "N3": (5.6, 8.3), "N4": (3.2, 7.0),
    "G1": (10.3, 3.1), "G2": (10.3, 1.1), "G3": (10.5, 0.0),
    "T": (8.2, 1.6),
}
SKETCH_WALL = ((0.0, 6.0), (14.0, 6.0))
# T sits deep in the wall shadow; the greens only graze the wall edge.
SKETCH_SHADOW = {"T": 1.0, "G1": 0.15, "G2": 0.15, "G3": 0.15, "N1": 0.0, "N2": 0.0, "N3": 0.0, "N4": 0.0}


def _orient(p, q, r):
    return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])


def _segments_cross(a1, a2, b1, b2):
    d1 = _orient(b1, b2, a1)
    d2 = _orient(b1, b2, a2)
    d3 = _orient(a1, a2, b1)
    d4 = _orient(a1, a2, b2)
    return d1 * d2 < 0 and d3 * d4 < 0


def sketch_pairs(rng, *, bias_lo=1.6, bias_hi=3.0, sigma=0.03):
    """Ranges for the sketch: wall-crossing links get bias * max shadow of their ends."""

    pairs = []
    biased = set()
    ids = sorted(SKETCH_TRUTH)
    for index, first in enumerate(ids):
        for second in ids[index + 1:]:
            truth = math.dist(SKETCH_TRUTH[first], SKETCH_TRUTH[second])
            measured = truth + rng.gauss(0.0, sigma)
            if _segments_cross(SKETCH_TRUTH[first], SKETCH_TRUTH[second], *SKETCH_WALL):
                bias = rng.uniform(bias_lo, bias_hi) * max(SKETCH_SHADOW[first], SKETCH_SHADOW[second])
                measured += bias
                if bias > 0.5:
                    biased.add((first, second))
            pairs.append(pair(first, second, measured))
    return pairs, biased


def sketch_neighbors(pairs):
    return {(item.anchor_a_id, item.anchor_b_id) for item in pairs}


def t_is_on_true_side(positions):
    """True when T and the N cluster lie on the same side of the G1-G3 line, as in truth."""

    centroid = (
        sum(positions[n][0] for n in ("N1", "N2", "N3", "N4")) / 4.0,
        sum(positions[n][1] for n in ("N1", "N2", "N3", "N4")) / 4.0,
    )
    t_side = _orient(positions["G1"], positions["G3"], positions["T"]) > 0
    n_side = _orient(positions["G1"], positions["G3"], centroid) > 0
    return t_side == n_side


def aligned_offset(truth, estimate, anchor):
    """Offset of ``anchor`` after a rigid fit (reflection allowed) on every other anchor."""

    ids = sorted(truth)
    reference = [a for a in ids if a != anchor]
    target = np.array([truth[a] for a in ids])
    source = np.array([estimate[a] for a in ids])
    rows = [ids.index(a) for a in reference]
    target_center = target[rows].mean(axis=0)
    source_center = source[rows].mean(axis=0)
    best = math.inf
    for reflection in (1.0, -1.0):
        moved = (source - source_center).copy()
        moved[:, 1] *= reflection
        u, _s, vt = np.linalg.svd(moved[rows].T @ (target[rows] - target_center))
        sign = np.sign(np.linalg.det(u @ vt))
        rotation = u @ np.diag([1.0, sign]) @ vt
        aligned = moved @ rotation + target_center
        fit = float(np.linalg.norm(aligned[rows] - target[rows], axis=1).mean())
        if fit < best:
            best = fit
            offset = float(np.linalg.norm(aligned[ids.index(anchor)] - target[ids.index(anchor)]))
    return offset


class SketchRegressionTests(unittest.TestCase):
    def test_symmetric_solver_mirrors_the_shadowed_anchor(self):
        pairs, _biased = sketch_pairs(random.Random(1001))
        result = solve_connectivity_interval_layout(
            pairs, neighbor_pairs=sketch_neighbors(pairs), nonneighbor_pairs=set(), seed=SEED_SPRING,
        )
        self.assertTrue(t_is_on_true_side(SKETCH_TRUTH))
        self.assertFalse(t_is_on_true_side(result.positions_m))

    def test_one_sided_solver_keeps_the_shadowed_anchor_in_place(self):
        pairs, biased = sketch_pairs(random.Random(1001))
        result = solve_nlos_one_sided_layout(
            pairs, neighbor_pairs=sketch_neighbors(pairs), nonneighbor_pairs=set(),
        )
        self.assertTrue(t_is_on_true_side(result.positions_m))
        self.assertLess(aligned_offset(SKETCH_TRUTH, result.positions_m, "T"), 0.3)
        nlos = [warning for warning in result.warnings if "treated as NLOS" in warning]
        self.assertEqual(len(nlos), 1)
        for first, second in biased:
            self.assertIn(f"{first}-{second} (+", nlos[0])
```

- [ ] **Step 2: Run the regression tests**

Run: `$PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos.SketchRegressionTests -v`
Expected: both PASS. If `test_symmetric_solver_mirrors_the_shadowed_anchor` fails because the spring seed happens not to flip for `random.Random(1001)`, switch that test to `seed=SEED_AUTO`; if it still does not flip, try `random.Random(1002)` for both tests. The spike flipped 80% of realisations at this bias range, so a seed that flips is expected within two tries. Record the seed actually used. If the one-sided test fails, do not loosen the 0.3 m bound; report the failure with the T offset and the NLOS warning text.

- [ ] **Step 3: Check runtime**

Run: `time $PY -m unittest tools.gateway_gui.tests.test_anchor_geometry_nlos`
Expected: under 30 s total. If the one-sided test takes longer than 15 s, pass `seed=SEED_SPRING` to it as well and note it.

---

### Task 5: GUI registration and dispatch

**Files:**
- Modify: `tools/gateway_gui/diagnostic_models.py` (imports near lines 20-31, `solve_geometry` near line 764)
- Modify: `tools/gateway_gui/survey_view.py` (imports near line 19-28, `SOLVER_CHOICES` and `RADIO_INTERVAL_SOLVERS` near lines 53-63)
- Modify: `tools/gateway_gui/diagnostics_integration.py` (import block near lines 13-47, tuples near lines 453-457 and 563-567)
- Test: `tools/gateway_gui/tests/test_geometry_diagnostics.py`, `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`

**Interfaces:**
- Consumes: `NLOS_ONE_SIDED_ALGORITHM`, `solve_nlos_one_sided_layout` from Task 3.
- Produces: `solve_geometry(..., solver=NLOS_ONE_SIDED_ALGORITHM)` dispatch; `SOLVER_CHOICES` and `RADIO_INTERVAL_SOLVERS` containing the name.

- [ ] **Step 1: Write the failing tests**

Add to `tools/gateway_gui/tests/test_geometry_diagnostics.py`, next to `test_selected_radio_interval_reaches_connectivity_solver`:

```python
    def test_seed_and_radio_interval_reach_nlos_solver(self):
        pairs = (pair("A", "B", 3.0), pair("A", "C", 4.0), pair("B", "C", 5.0))
        with patch(
            "tools.gateway_gui.diagnostic_models.solve_nlos_one_sided_layout",
            return_value="sentinel",
        ) as nlos:
            result = solve_geometry(
                pairs,
                solver=NLOS_ONE_SIDED_ALGORITHM,
                seed=SEED_SPRING,
                neighbor_pairs=frozenset({("A", "B")}),
                nonneighbor_pairs=frozenset({("A", "C")}),
                nonneighbor_min_m=5.5,
                neighbor_max_m=22.5,
            )
        self.assertEqual(result, "sentinel")
        self.assertEqual(nlos.call_args.kwargs["seed"], SEED_SPRING)
        self.assertEqual(nlos.call_args.kwargs["nonneighbor_min_m"], 5.5)
        self.assertEqual(nlos.call_args.kwargs["neighbor_max_m"], 22.5)
        self.assertEqual(nlos.call_args.kwargs["neighbor_pairs"], frozenset({("A", "B")}))
        self.assertEqual(nlos.call_args.kwargs["nonneighbor_pairs"], frozenset({("A", "C")}))
```

and add `from tools.gateway_gui.anchor_geometry_nlos import NLOS_ONE_SIDED_ALGORITHM` to that file's imports.

Append to `tools/gateway_gui/tests/test_anchor_geometry_nlos.py`:

```python
class RegistrationTests(unittest.TestCase):
    def test_solver_is_selectable_and_uses_the_radio_interval(self):
        from tools.gateway_gui.survey_view import RADIO_INTERVAL_SOLVERS, SOLVER_CHOICES

        self.assertIn(NLOS_ONE_SIDED_ALGORITHM, SOLVER_CHOICES)
        self.assertIn(NLOS_ONE_SIDED_ALGORITHM, RADIO_INTERVAL_SOLVERS)
        self.assertEqual(SOLVER_CHOICES[0], "Neighbor intervals")
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `$PY -m unittest tools.gateway_gui.tests.test_geometry_diagnostics tools.gateway_gui.tests.test_anchor_geometry_nlos.RegistrationTests -v`
Expected: the dispatch test fails with `ValueError: Unknown geometry solver` or an AttributeError on the patch target; the registration test fails on `assertIn`.

- [ ] **Step 3: Register the solver**

In `tools/gateway_gui/diagnostic_models.py`, after the `anchor_geometry_connectivity` import block add:

```python
from .anchor_geometry_nlos import (
    NLOS_ONE_SIDED_ALGORITHM,
    solve_nlos_one_sided_layout,
)
```

and in `solve_geometry`, directly after the `CONNECTIVITY_INTERVAL_ALGORITHM` branch add:

```python
    if solver == NLOS_ONE_SIDED_ALGORITHM:
        return solve_nlos_one_sided_layout(
            pairs,
            neighbor_pairs=neighbor_pairs,
            nonneighbor_pairs=nonneighbor_pairs,
            seed=seed,
            current_positions_m=current_positions_m,
            nonneighbor_min_m=nonneighbor_min_m,
            neighbor_max_m=neighbor_max_m,
        )
```

In `tools/gateway_gui/survey_view.py` add `from .anchor_geometry_nlos import NLOS_ONE_SIDED_ALGORITHM` next to the other geometry imports and change the two tuples to:

```python
SOLVER_CHOICES = (
    CONNECTIVITY_INTERVAL_ALGORITHM,
    NLOS_ONE_SIDED_ALGORITHM,
    VISIBILITY_BRANCHING_TUNED_ALGORITHM,
    VISIBILITY_BRANCHING_NEIGHBOR_AWARE_ALGORITHM,
    "Spring energy",
)
RADIO_INTERVAL_SOLVERS = frozenset((
    CONNECTIVITY_INTERVAL_ALGORITHM,
    NLOS_ONE_SIDED_ALGORITHM,
    VISIBILITY_BRANCHING_TUNED_ALGORITHM,
    VISIBILITY_BRANCHING_NEIGHBOR_AWARE_ALGORITHM,
))
```

Keep whatever other entries `SOLVER_CHOICES` already has (check the current file; `"Spring energy"` is shown here because `solve_geometry` accepts it, keep the existing order for everything but the inserted name).

In `tools/gateway_gui/diagnostics_integration.py` extend the existing `from .survey_view import LayoutRegistration, SurveyGeometryView` to also import `RADIO_INTERVAL_SOLVERS`, and replace both hand-written tuples:

```python
        if view is not None and solver in RADIO_INTERVAL_SOLVERS:
```

and

```python
        interval = (
            f" (radio interval {neighbor_min_m:g}-{neighbor_max_m:g} m)"
            if solver in RADIO_INTERVAL_SOLVERS
            else ""
        )
```

If, after this change, `CONNECTIVITY_INTERVAL_ALGORITHM`, `VISIBILITY_BRANCHING_TUNED_ALGORITHM`, or `VISIBILITY_BRANCHING_NEIGHBOR_AWARE_ALGORITHM` is no longer referenced anywhere in `diagnostics_integration.py`, remove it from that file's imports.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `$PY -m unittest tools.gateway_gui.tests.test_geometry_diagnostics tools.gateway_gui.tests.test_anchor_geometry_nlos -v`
Expected: all PASS.

- [ ] **Step 5: Run the GUI gates**

Run:
```sh
$PY -m unittest discover -s tools/gateway_gui/tests
$PY -m compileall -q tools/gateway_gui
$PY -m mypy --explicit-package-bases --exclude 'tools/gateway_gui/tests/' tools/gateway_gui
```
Expected: all OK, `Success: no issues found`.

---

### Task 6: Documentation

**Files:**
- Modify: `tools/gateway_gui/README.md` (after the `Visibility branching neighbor-aware tuned` paragraph, near line 268-281)
- Modify: `AGENT_KNOWN_ISSUES.md` (append one line at the end, matching the existing `- 2026-09-03: ...` line format)

- [ ] **Step 1: Add the README paragraph**

Insert after the `Visibility branching neighbor-aware tuned` paragraph:

```markdown
`NLOS one-sided intervals` is the solver to pick when an anchor lands on the
mirrored side of its near neighbours because most of its other links cross a
wall. UWB non-line-of-sight bias only lengthens a range, so this solver keeps
the ranging sigma when the solved distance is longer than the measurement and
lets the penalty saturate when it is shorter; a biased link then stops pulling
its anchor away from the far anchors. Short links are weighted up because they
are rarely obstructed, and an explicit per-anchor reflection search visits both
mirror placements, which a gradient step alone cannot do. It uses the same
radio minimum and neighbor maximum as `Neighbor intervals`. The result reports
`N link(s) treated as NLOS` with the measured excess over the solved distance
so the untrusted ranges are visible. It needs the merged `Survey All Neighbors`
dataset; on a single degree-capped pass every solver is under-determined. When
every far link of an anchor is obstructed with a bias larger than its distance
to the mirror line and its near neighbours are collinear, ranges alone cannot
decide the side, so the manual mirror control still matters.
```

- [ ] **Step 2: Add the known-issues line**

Append to `AGENT_KNOWN_ISSUES.md`:

```markdown
- 2026-09-05: The GUI geometry solvers mirrored a wall-shadowed anchor across its near-collinear neighbours because symmetric least squares treats a too-long NLOS range like a too-short one; the new selectable `NLOS one-sided intervals` solver saturates the penalty for model-shorter-than-measured links, weights short links up, and runs a per-anchor reflection search, which removed the flip on the reported geometry and on random wall layouts.
```

- [ ] **Step 3: Verify docs render and gates still pass**

Run: `$PY -m unittest discover -s tools/gateway_gui/tests`
Expected: OK.
